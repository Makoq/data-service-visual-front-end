function aa(){
    alert('a')
}