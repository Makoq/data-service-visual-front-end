
export default {
  chartData: {
    // 保存所有的组件
    elements: [],
  },
  currentElementIndex: -1,
  scale: 0.7,
  colorNo:-1,
  colorCount:{}
   
};
