
export const SET_ACTIVE_COMPONENT_BY_INDEX = 'set_active_component_by_index';
export const CHANGE_SCALE = 'change_scale';
export const ADD_COMPONENT = 'add_component';
export const DELETE_COMPONENT = 'delete_component';
export const SET_DATA = 'set_component_data';
export const CHANGE_COLOR="change_color";
export const SET_COLOR_COUNT="set_color_count"
export const MOVE_UP="move_up_element";
export const MOVE_DOWN="move_down_element";
export const CHANGE_SCREEN_BKG="change_screen_bg";



