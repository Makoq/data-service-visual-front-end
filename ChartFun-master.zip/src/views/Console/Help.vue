<template>
   <div>

 node = get_node_by_name(node_name, parent_node_name=null)<br>
node = get_child_by_index(node_name, index)<br>
int = get_child_count(node_name)<br>
int = get_node_length(node_name)<br>
real/int/string = get_item_by_index(node_name,index)// real_array, int_array, string_array<br>
// udx_value<br>

// 重载方法<br>
node = get_node_by_name(node_name, parent_node=null)<br>
node = get_child_by_index(node, index)<br>
int = get_child_count(node)<br>
int = get_node_length(node)<br>
real/int/string = get_item_by_index(node,index)<br>

any
list
int
real
string
vector2d
vector3d
vector4d
int_array
real_array
string_array
vector2d_array
vector3d_array
vector4d_array

   </div>
</template>
<script>
export default {
  data() {
    return {

    };
  },
};
</script>
<style lang="scss">
</style>
