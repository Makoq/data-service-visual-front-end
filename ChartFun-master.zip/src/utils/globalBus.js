import Vue from 'vue';
export const globalBus = new Vue();